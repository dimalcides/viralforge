"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type DragEvent,
  type ReactNode,
} from "react";

import {
  ACCEPTED_IMAGE_TYPES,
  CRITERIA_LABELS,
  DEFAULT_SLIDES,
  FORM_FIELDS,
  MAX_IMAGE_BYTES,
  MAX_OWN_IMAGES,
  MAX_PDF_BYTES,
  MAX_REF_IMAGES,
  MAX_SLIDES,
  MIN_SLIDES,
  OBJECTIVES,
  OBJECTIVE_LABELS,
  type AppTab,
  type GenerateResponse,
  type GenerateResult,
  type GenerationMode,
  type GeneratorFormState,
  type GeneratorStatus,
  type ImageItem,
  type MediaMode,
  type Objective,
  type ScoreCriteria,
  type ScriptKind,
  type Slide,
} from "@/types/viralforge";

/* -------------------------------------------------------------------------- */
/* Utilidades                                                                 */
/* -------------------------------------------------------------------------- */

function cn(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(" ");
}

function formatMb(bytes: number): string {
  return `${Math.round(bytes / (1024 * 1024))} MB`;
}

function createImageItem(file: File): ImageItem {
  return {
    id: `${file.name}-${file.size}-${file.lastModified}-${Math.random().toString(36).slice(2, 8)}`,
    file,
    previewUrl: URL.createObjectURL(file),
  };
}

function isAcceptedImage(file: File): boolean {
  return (ACCEPTED_IMAGE_TYPES as readonly string[]).includes(file.type);
}

const INITIAL_FORM: GeneratorFormState = {
  pdf: null,
  refs: [],
  ownImages: [],
  objective: "compartilhamento",
  slides: DEFAULT_SLIDES,
  media: "sugerir",
  scriptKind: "roteiro_carrossel",
};

const TABS: { id: AppTab; label: string }[] = [
  { id: "carrossel", label: "Carrossel" },
  { id: "roteiros", label: "Roteiros" },
  { id: "arquitetura", label: "Arquitetura" },
];

/* -------------------------------------------------------------------------- */
/* Componente principal                                                       */
/* -------------------------------------------------------------------------- */

export default function CarouselGenerator() {
  const [tab, setTab] = useState<AppTab>("carrossel");
  const [form, setForm] = useState<GeneratorFormState>(INITIAL_FORM);
  const [status, setStatus] = useState<GeneratorStatus>({ kind: "idle" });
  const [fileError, setFileError] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const formRef = useRef(form);
  formRef.current = form;

  // Revoga as URLs de pré-visualização e cancela requisições ao desmontar.
  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      [...formRef.current.refs, ...formRef.current.ownImages].forEach((item) =>
        URL.revokeObjectURL(item.previewUrl),
      );
    };
  }, []);

  const isLoading = status.kind === "loading";

  const patch = useCallback((changes: Partial<GeneratorFormState>) => {
    setForm((current) => ({ ...current, ...changes }));
  }, []);

  const handlePdf = useCallback(
    (files: File[]) => {
      const file = files[0];
      if (!file) return;
      if (file.type !== "application/pdf") {
        setFileError("O arquivo precisa estar em formato PDF.");
        return;
      }
      if (file.size > MAX_PDF_BYTES) {
        setFileError(`O PDF excede o limite de ${formatMb(MAX_PDF_BYTES)}.`);
        return;
      }
      setFileError(null);
      patch({ pdf: file });
    },
    [patch],
  );

  const addImages = useCallback(
    (key: "refs" | "ownImages", max: number, files: File[]) => {
      const valid: File[] = [];
      let message: string | null = null;

      for (const file of files) {
        if (!isAcceptedImage(file)) {
          message = `"${file.name}" não é JPG, PNG, WebP ou GIF.`;
        } else if (file.size > MAX_IMAGE_BYTES) {
          message = `"${file.name}" excede ${formatMb(MAX_IMAGE_BYTES)}.`;
        } else {
          valid.push(file);
        }
      }

      setForm((current) => {
        const room = max - current[key].length;
        if (valid.length > room) message = `Limite de ${max} imagens nesta área.`;
        const added = valid.slice(0, Math.max(room, 0)).map(createImageItem);
        return { ...current, [key]: [...current[key], ...added] };
      });
      setFileError(message);
    },
    [],
  );

  const removeImage = useCallback((key: "refs" | "ownImages", id: string) => {
    setForm((current) => {
      const target = current[key].find((item) => item.id === id);
      if (target) URL.revokeObjectURL(target.previewUrl);
      return { ...current, [key]: current[key].filter((item) => item.id !== id) };
    });
  }, []);

  const mode: GenerationMode = tab === "roteiros" ? form.scriptKind : "carrossel";
  const usesSlideCount = mode !== "reels";
  const needsOwnImages = mode === "carrossel" && form.media === "usuario";

  const handleGenerate = useCallback(async () => {
    if (!form.pdf) {
      setStatus({ kind: "error", message: "Envie um PDF antes de gerar." });
      return;
    }
    if (needsOwnImages && form.ownImages.length === 0) {
      setStatus({
        kind: "error",
        message: "Envie ao menos uma imagem própria ou escolha a opção de imagens sugeridas.",
      });
      return;
    }

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setStatus({ kind: "loading" });

    const body = new FormData();
    body.append(FORM_FIELDS.pdf, form.pdf);
    form.refs.forEach((item) => body.append(FORM_FIELDS.refs, item.file));
    if (needsOwnImages) {
      form.ownImages.forEach((item) => body.append(FORM_FIELDS.ownImages, item.file));
    }
    body.append(FORM_FIELDS.mode, mode);
    body.append(FORM_FIELDS.objective, form.objective);
    body.append(FORM_FIELDS.slides, String(form.slides));
    body.append(FORM_FIELDS.media, mode === "carrossel" ? form.media : "sugerir");

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        body,
        signal: controller.signal,
      });

      let payload: GenerateResponse | null = null;
      try {
        payload = (await response.json()) as GenerateResponse;
      } catch {
        payload = null;
      }

      if (!payload) {
        setStatus({
          kind: "error",
          message:
            response.status === 413
              ? "Os arquivos são grandes demais para o servidor. Reduza o tamanho do PDF ou das imagens."
              : "O servidor retornou uma resposta inesperada. Tente novamente.",
        });
        return;
      }
      if (!payload.ok) {
        setStatus({ kind: "error", message: payload.error.message });
        return;
      }
      setStatus({ kind: "success", mode: payload.mode, result: payload.result });
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      setStatus({
        kind: "error",
        message: "Não foi possível conectar ao servidor. Verifique sua conexão e tente novamente.",
      });
    }
  }, [form, mode, needsOwnImages]);

  return (
    <div className="min-h-screen bg-stone-100 text-stone-900 dark:bg-zinc-950 dark:text-stone-100">
      <header className="flex flex-wrap items-center gap-3 border-b border-stone-200 bg-white px-5 py-4 dark:border-zinc-800 dark:bg-zinc-900">
        <h1 className="text-lg font-extrabold tracking-tight">
          Viral<span className="text-orange-600 dark:text-orange-400">Forge</span>
        </h1>
        <div role="tablist" aria-label="Seções" className="ml-auto flex gap-1">
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              role="tab"
              id={`tab-${item.id}`}
              aria-selected={tab === item.id}
              aria-controls={`panel-${item.id}`}
              onClick={() => setTab(item.id)}
              className={cn(
                "rounded-lg px-3.5 py-2 text-sm font-semibold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-orange-500",
                tab === item.id
                  ? "bg-orange-50 text-orange-700 dark:bg-orange-950 dark:text-orange-300"
                  : "text-stone-500 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-stone-100",
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
      </header>

      {tab === "arquitetura" ? (
        <main
          role="tabpanel"
          id="panel-arquitetura"
          aria-labelledby="tab-arquitetura"
          className="mx-auto max-w-4xl p-5"
        >
          <ArchitectureTab />
        </main>
      ) : (
        <main
          role="tabpanel"
          id={`panel-${tab}`}
          aria-labelledby={`tab-${tab}`}
          className="mx-auto grid max-w-6xl gap-5 p-5 lg:grid-cols-[400px_minmax(0,1fr)]"
        >
          <section aria-label="Configurações" className="space-y-4">
            <Card title="Conteúdo base">
              <Dropzone
                id="pdf-input"
                accept="application/pdf"
                onFiles={handlePdf}
                label={form.pdf ? form.pdf.name : "Enviar PDF com as ideias a resumir"}
                hint={form.pdf ? `${(form.pdf.size / 1024 / 1024).toFixed(1)} MB. Clique para trocar.` : `Até ${formatMb(MAX_PDF_BYTES)}`}
              />
              <div className="mt-4">
                <p className="mb-1.5 text-sm font-semibold">Referências que performaram bem</p>
                <Dropzone
                  id="refs-input"
                  accept={ACCEPTED_IMAGE_TYPES.join(",")}
                  multiple
                  onFiles={(files) => addImages("refs", MAX_REF_IMAGES, files)}
                  label="Enviar imagens de carrosséis de referência"
                  hint={`Até ${MAX_REF_IMAGES} imagens. Servem de padrão de estrutura e tom de voz.`}
                />
                <Thumbnails items={form.refs} onRemove={(id) => removeImage("refs", id)} />
              </div>
              {fileError && (
                <p role="alert" className="mt-3 text-sm text-red-600 dark:text-red-400">
                  {fileError}
                </p>
              )}
            </Card>

            <Card title="Parâmetros">
              {tab === "roteiros" && (
                <fieldset className="mb-4">
                  <legend className="mb-1.5 text-sm font-semibold">Tipo de roteiro</legend>
                  <div className="grid gap-2">
                    <OptionRadio<ScriptKind>
                      name="scriptKind"
                      value="roteiro_carrossel"
                      checked={form.scriptKind === "roteiro_carrossel"}
                      onChange={(scriptKind) => patch({ scriptKind })}
                      title="Roteiro textual do carrossel"
                      description="Apenas os textos de cada slide, sem imagens."
                    />
                    <OptionRadio<ScriptKind>
                      name="scriptKind"
                      value="reels"
                      checked={form.scriptKind === "reels"}
                      onChange={(scriptKind) => patch({ scriptKind })}
                      title="Reels ou vídeo curto"
                      description="Gancho, corpo e CTA pensados para retenção."
                    />
                  </div>
                </fieldset>
              )}

              <fieldset>
                <legend className="mb-1.5 text-sm font-semibold">Objetivo</legend>
                <div className="grid gap-2">
                  {OBJECTIVES.map((value) => (
                    <OptionRadio<Objective>
                      key={value}
                      name="objective"
                      value={value}
                      checked={form.objective === value}
                      onChange={(objective) => patch({ objective })}
                      title={OBJECTIVE_LABELS[value].label}
                      description={OBJECTIVE_LABELS[value].description}
                    />
                  ))}
                </div>
              </fieldset>

              {usesSlideCount && (
                <div className="mt-4">
                  <label htmlFor="slides-range" className="mb-1.5 block text-sm font-semibold">
                    Número de slides: {form.slides}
                  </label>
                  <input
                    id="slides-range"
                    type="range"
                    min={MIN_SLIDES}
                    max={MAX_SLIDES}
                    value={form.slides}
                    onChange={(e: ChangeEvent<HTMLInputElement>) =>
                      patch({ slides: Number(e.target.value) })
                    }
                    className="w-full accent-orange-600"
                  />
                  <p className="text-xs text-stone-500 dark:text-zinc-400">
                    O slide 1 é sempre a capa e o último é a chamada para ação.
                  </p>
                </div>
              )}

              {mode === "carrossel" && (
                <fieldset className="mt-4">
                  <legend className="mb-1.5 text-sm font-semibold">Imagens dos slides</legend>
                  <div className="grid gap-2">
                    <OptionRadio<MediaMode>
                      name="media"
                      value="sugerir"
                      checked={form.media === "sugerir"}
                      onChange={(media) => patch({ media })}
                      title="Sugerir uma imagem por slide"
                      description="A IA descreve a imagem ideal para cada slide."
                    />
                    <OptionRadio<MediaMode>
                      name="media"
                      value="usuario"
                      checked={form.media === "usuario"}
                      onChange={(media) => patch({ media })}
                      title="Usar minhas imagens"
                      description="A IA distribui suas imagens entre os slides."
                    />
                  </div>
                  {form.media === "usuario" && (
                    <div className="mt-3">
                      <Dropzone
                        id="own-input"
                        accept={ACCEPTED_IMAGE_TYPES.join(",")}
                        multiple
                        onFiles={(files) => addImages("ownImages", MAX_OWN_IMAGES, files)}
                        label="Enviar minhas imagens"
                        hint={`Até ${MAX_OWN_IMAGES} imagens`}
                      />
                      <Thumbnails
                        items={form.ownImages}
                        onRemove={(id) => removeImage("ownImages", id)}
                      />
                    </div>
                  )}
                </fieldset>
              )}
            </Card>

            <button
              type="button"
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full rounded-xl bg-orange-600 px-4 py-3 font-bold text-white transition-colors hover:bg-orange-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-orange-500 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isLoading ? "Analisando o PDF e gerando…" : tab === "roteiros" ? "Gerar roteiro" : "Gerar carrossel"}
            </button>
          </section>

          <section aria-label="Resultado" aria-live="polite" className="min-w-0">
            <ResultArea status={status} />
          </section>
        </main>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Blocos de formulário                                                       */
/* -------------------------------------------------------------------------- */

function Card({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
      <h2 className="mb-3 text-sm font-semibold text-stone-500 dark:text-zinc-400">{title}</h2>
      {children}
    </div>
  );
}

interface DropzoneProps {
  id: string;
  accept: string;
  multiple?: boolean;
  label: string;
  hint: string;
  onFiles: (files: File[]) => void;
}

function Dropzone({ id, accept, multiple, label, hint, onFiles }: DropzoneProps) {
  const [dragging, setDragging] = useState(false);

  const handleDrop = (event: DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    setDragging(false);
    onFiles(Array.from(event.dataTransfer.files));
  };

  return (
    <label
      htmlFor={id}
      onDragOver={(event) => {
        event.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      className={cn(
        "block cursor-pointer rounded-xl border-2 border-dashed px-3 py-4 text-center transition-colors focus-within:outline focus-within:outline-2 focus-within:outline-orange-500",
        dragging
          ? "border-orange-500 bg-orange-50 dark:bg-orange-950"
          : "border-stone-300 hover:border-orange-500 dark:border-zinc-700",
      )}
    >
      <input
        id={id}
        type="file"
        accept={accept}
        multiple={multiple}
        className="sr-only"
        onChange={(event: ChangeEvent<HTMLInputElement>) => {
          onFiles(Array.from(event.target.files ?? []));
          event.target.value = "";
        }}
      />
      <span className="block text-sm font-medium break-words">{label}</span>
      <span className="mt-0.5 block text-xs text-stone-500 dark:text-zinc-400">{hint}</span>
    </label>
  );
}

function Thumbnails({ items, onRemove }: { items: ImageItem[]; onRemove: (id: string) => void }) {
  if (items.length === 0) return null;
  return (
    <ul className="mt-2 flex flex-wrap gap-2">
      {items.map((item) => (
        <li key={item.id} className="group relative">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={item.previewUrl}
            alt={item.file.name}
            className="h-14 w-14 rounded-lg border border-stone-200 object-cover dark:border-zinc-700"
          />
          <button
            type="button"
            onClick={() => onRemove(item.id)}
            aria-label={`Remover ${item.file.name}`}
            className="absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-stone-900 text-xs leading-none text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-orange-500 dark:bg-stone-100 dark:text-stone-900"
          >
            ×
          </button>
        </li>
      ))}
    </ul>
  );
}

interface OptionRadioProps<T extends string> {
  name: string;
  value: T;
  checked: boolean;
  onChange: (value: T) => void;
  title: string;
  description: string;
}

function OptionRadio<T extends string>({
  name,
  value,
  checked,
  onChange,
  title,
  description,
}: OptionRadioProps<T>) {
  return (
    <label
      className={cn(
        "flex cursor-pointer items-start gap-2.5 rounded-xl border p-2.5 transition-colors focus-within:outline focus-within:outline-2 focus-within:outline-orange-500",
        checked
          ? "border-orange-500 bg-orange-50 dark:bg-orange-950"
          : "border-stone-200 dark:border-zinc-700",
      )}
    >
      <input
        type="radio"
        name={name}
        value={value}
        checked={checked}
        onChange={() => onChange(value)}
        className="mt-1 accent-orange-600"
      />
      <span className="text-sm">
        <span className="block font-medium">{title}</span>
        <span className="block text-xs text-stone-500 dark:text-zinc-400">{description}</span>
      </span>
    </label>
  );
}

/* -------------------------------------------------------------------------- */
/* Resultado                                                                  */
/* -------------------------------------------------------------------------- */

function ResultArea({ status }: { status: GeneratorStatus }) {
  if (status.kind === "idle") {
    return (
      <div className="rounded-2xl border border-dashed border-stone-300 p-10 text-center text-stone-500 dark:border-zinc-700 dark:text-zinc-400">
        Envie um PDF, escolha o objetivo e clique em gerar para ver o resultado aqui.
      </div>
    );
  }
  if (status.kind === "loading") {
    return (
      <div className="space-y-3" role="status" aria-label="Gerando conteúdo">
        <div className="h-24 animate-pulse rounded-2xl bg-stone-200 dark:bg-zinc-800" />
        <div className="h-64 animate-pulse rounded-2xl bg-stone-200 dark:bg-zinc-800" />
        <div className="h-40 animate-pulse rounded-2xl bg-stone-200 dark:bg-zinc-800" />
      </div>
    );
  }
  if (status.kind === "error") {
    return (
      <div
        role="alert"
        className="rounded-2xl border border-red-300 bg-red-50 p-4 text-sm text-red-800 dark:border-red-900 dark:bg-red-950 dark:text-red-200"
      >
        <p className="font-semibold">Não foi possível gerar o conteúdo</p>
        <p className="mt-1">{status.message}</p>
      </div>
    );
  }
  return <ResultView mode={status.mode} result={status.result} />;
}

function resultToText(mode: GenerationMode, result: GenerateResult): string {
  const lines: string[] = [];
  if (mode === "reels" && result.reels) {
    lines.push("GANCHO", result.reels.gancho, "", "CORPO");
    result.reels.corpo.forEach((block, index) => lines.push(`${index + 1}. ${block}`));
    lines.push("", "CTA", result.reels.cta);
  } else {
    result.slides.forEach((slide) => {
      lines.push(`Slide ${slide.n} (${slide.tipo})`, slide.titulo, slide.corpo);
      if (slide.imagem) lines.push(`Imagem: ${slide.imagem}`);
      lines.push("");
    });
  }
  return lines.join("\n").trim();
}

function ResultView({ mode, result }: { mode: GenerationMode; result: GenerateResult }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(resultToText(mode, result));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const title =
    mode === "reels" ? "Roteiro de Reels" : mode === "roteiro_carrossel" ? "Roteiro do carrossel" : "Carrossel";

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
        <h2 className="text-sm font-semibold text-stone-500 dark:text-zinc-400">Resumo do PDF</h2>
        <p className="mt-1.5 text-sm leading-relaxed">{result.resumo_pdf}</p>
      </div>

      <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-sm font-semibold text-stone-500 dark:text-zinc-400">{title}</h2>
          <button
            type="button"
            onClick={copy}
            className="rounded-lg border border-stone-300 px-3 py-1.5 text-xs font-semibold hover:border-orange-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-orange-500 dark:border-zinc-700"
          >
            {copied ? "Copiado" : "Copiar texto"}
          </button>
        </div>
        {mode === "reels" && result.reels ? (
          <ReelsView reels={result.reels} />
        ) : (
          <SlidesView slides={result.slides} showImages={mode === "carrossel"} />
        )}
      </div>

      <ScorePanel result={result} />
    </div>
  );
}

const SLIDE_STYLES: Record<Slide["tipo"], string> = {
  capa: "from-orange-600 to-rose-900",
  conteudo: "from-indigo-800 to-slate-900",
  cta: "from-emerald-700 to-teal-900",
};

const SLIDE_LABELS: Record<Slide["tipo"], string> = {
  capa: "Capa",
  conteudo: "Conteúdo",
  cta: "Chamada para ação",
};

function SlidesView({ slides, showImages }: { slides: Slide[]; showImages: boolean }) {
  return (
    <ol className="flex snap-x gap-3 overflow-x-auto pb-2">
      {slides.map((slide) => (
        <li
          key={slide.n}
          className={cn(
            "flex aspect-[4/5] w-56 flex-none snap-start flex-col justify-between rounded-xl bg-gradient-to-br p-3.5 text-white",
            SLIDE_STYLES[slide.tipo],
          )}
        >
          <div>
            <p className="text-xs opacity-80">
              {slide.n}/{slides.length} · {SLIDE_LABELS[slide.tipo]}
            </p>
            <h3 className="mt-1.5 text-base font-bold leading-tight">{slide.titulo}</h3>
            <p className="mt-1.5 text-[13px] leading-snug opacity-95">{slide.corpo}</p>
          </div>
          {showImages && slide.imagem && (
            <p className="rounded-md bg-white/20 px-2 py-1 text-[11px] leading-snug">{slide.imagem}</p>
          )}
        </li>
      ))}
    </ol>
  );
}

function ReelsView({ reels }: { reels: NonNullable<GenerateResult["reels"]> }) {
  return (
    <div className="space-y-3 text-sm">
      <ScriptBlock heading="Gancho (0 a 3 s)">{reels.gancho}</ScriptBlock>
      <ScriptBlock heading="Corpo">
        <ol className="list-decimal space-y-1.5 pl-5">
          {reels.corpo.map((block, index) => (
            <li key={index}>{block}</li>
          ))}
        </ol>
      </ScriptBlock>
      <ScriptBlock heading="Chamada para ação">{reels.cta}</ScriptBlock>
    </div>
  );
}

function ScriptBlock({ heading, children }: { heading: string; children: ReactNode }) {
  return (
    <div className="border-l-4 border-orange-500 pl-3">
      <p className="mb-1 font-semibold text-orange-700 dark:text-orange-300">{heading}</p>
      <div className="leading-relaxed">{children}</div>
    </div>
  );
}

function ScorePanel({ result }: { result: GenerateResult }) {
  const { score } = result;
  const criteria = Object.keys(CRITERIA_LABELS) as (keyof ScoreCriteria)[];

  return (
    <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
      <h2 className="mb-3 text-sm font-semibold text-stone-500 dark:text-zinc-400">
        Potencial de viralização
      </h2>
      <div className="flex flex-wrap items-center gap-5">
        <div
          role="img"
          aria-label={`Potencial de viralização: ${score.total}%`}
          className="grid h-28 w-28 flex-none place-items-center rounded-full"
          style={{
            background: `conic-gradient(#ea580c ${score.total * 3.6}deg, rgb(168 162 158 / 0.3) 0)`,
          }}
        >
          <span className="grid h-[86px] w-[86px] place-items-center rounded-full bg-white text-2xl font-extrabold dark:bg-zinc-900">
            {score.total}%
          </span>
        </div>
        <ul className="min-w-[220px] flex-1 space-y-2">
          {criteria.map((key) => (
            <li key={key}>
              <div className="flex justify-between text-xs">
                <span>{CRITERIA_LABELS[key]}</span>
                <span className="font-semibold">{score.criterios[key]}</span>
              </div>
              <div className="mt-1 h-1.5 rounded bg-stone-200 dark:bg-zinc-700">
                <div
                  className="h-full rounded bg-orange-600"
                  style={{ width: `${score.criterios[key]}%` }}
                />
              </div>
            </li>
          ))}
        </ul>
      </div>
      <div className="mt-4 grid gap-4 text-sm sm:grid-cols-2">
        <div>
          <h3 className="font-semibold text-emerald-700 dark:text-emerald-400">Pontos fortes</h3>
          <ul className="mt-1 list-disc space-y-1 pl-5">
            {score.pontos_fortes.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="font-semibold">Sugestões de melhoria</h3>
          <ul className="mt-1 list-disc space-y-1 pl-5">
            {score.melhorias.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Aba de arquitetura                                                         */
/* -------------------------------------------------------------------------- */

const STACK: { name: string; detail: string }[] = [
  { name: "Next.js 15 (App Router) e TypeScript", detail: "Interface e Route Handlers no mesmo projeto." },
  { name: "Tailwind CSS", detail: "Estilos utilitários com suporte a modo escuro." },
  { name: "API da Anthropic", detail: "Lê o PDF e as imagens diretamente e devolve JSON estruturado." },
  { name: "Zod", detail: "Valida os parâmetros de entrada e o JSON devolvido pelo modelo." },
  { name: "Supabase ou S3 (opcional)", detail: "Histórico, autenticação e armazenamento de arquivos." },
  { name: "Vercel", detail: "Hospedagem, com maxDuration de 120 s na rota de geração." },
];

const FLOW: string[] = [
  "O navegador envia o PDF, as imagens e os parâmetros em multipart/form-data para /api/generate.",
  "A rota limita a frequência por IP e valida tipo, tamanho e assinatura dos arquivos.",
  "O PDF e as imagens seguem para a API da Anthropic junto com o system prompt do ViralForge.",
  "O JSON devolvido é validado. Se estiver fora do formato, a rota pede uma correção uma vez.",
  "O servidor impõe capa no primeiro slide e CTA no último, e recalcula o score pelos pesos dos critérios.",
  "O resultado volta tipado (GenerateResponse) e o componente exibe slides, roteiro e painel de score.",
];

function ArchitectureTab() {
  return (
    <div className="space-y-4">
      <Card title="Stack">
        <ul className="grid gap-3 sm:grid-cols-2">
          {STACK.map((item) => (
            <li key={item.name} className="text-sm">
              <span className="block font-semibold">{item.name}</span>
              <span className="text-stone-600 dark:text-zinc-400">{item.detail}</span>
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Fluxo de uma geração">
        <ol className="list-decimal space-y-2 pl-5 text-sm">
          {FLOW.map((step) => (
            <li key={step}>{step}</li>
          ))}
        </ol>
      </Card>

      <Card title="Configuração">
        <dl className="space-y-2 text-sm">
          <div>
            <dt className="font-semibold">ANTHROPIC_API_KEY (obrigatória)</dt>
            <dd className="text-stone-600 dark:text-zinc-400">Chave da API, definida somente no servidor.</dd>
          </div>
          <div>
            <dt className="font-semibold">ANTHROPIC_MODEL (opcional)</dt>
            <dd className="text-stone-600 dark:text-zinc-400">Troca o modelo usado sem alterar o código.</dd>
          </div>
        </dl>
      </Card>
    </div>
  );
}
