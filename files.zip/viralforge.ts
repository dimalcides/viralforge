/**
 * Tipos e constantes compartilhados entre a rota /api/generate e o componente
 * CarouselGenerator. Manter tudo aqui evita divergência entre cliente e servidor.
 */

/* -------------------------------------------------------------------------- */
/* Enumerações                                                                */
/* -------------------------------------------------------------------------- */

export const OBJECTIVES = [
  "compartilhamento",
  "retencao_salvamento",
  "comentarios",
] as const;
export type Objective = (typeof OBJECTIVES)[number];

export const GENERATION_MODES = ["carrossel", "roteiro_carrossel", "reels"] as const;
export type GenerationMode = (typeof GENERATION_MODES)[number];

export const MEDIA_MODES = ["sugerir", "usuario"] as const;
export type MediaMode = (typeof MEDIA_MODES)[number];

export const SLIDE_TYPES = ["capa", "conteudo", "cta"] as const;
export type SlideType = (typeof SLIDE_TYPES)[number];

export type AppTab = "carrossel" | "roteiros" | "arquitetura";
export type ScriptKind = "roteiro_carrossel" | "reels";

/* -------------------------------------------------------------------------- */
/* Limites (validados no cliente e no servidor)                               */
/* -------------------------------------------------------------------------- */

export const MIN_SLIDES = 2;
export const MAX_SLIDES = 10;
export const DEFAULT_SLIDES = 7;

export const MAX_PDF_BYTES = 20 * 1024 * 1024;
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export const MAX_REF_IMAGES = 6;
export const MAX_OWN_IMAGES = 10;

export const ACCEPTED_IMAGE_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
] as const;
export type AcceptedImageType = (typeof ACCEPTED_IMAGE_TYPES)[number];

/** Nomes dos campos do multipart/form-data enviados para /api/generate. */
export const FORM_FIELDS = {
  pdf: "pdf",
  refs: "refs",
  ownImages: "ownImages",
  mode: "mode",
  objective: "objective",
  slides: "slides",
  media: "media",
} as const;

/* -------------------------------------------------------------------------- */
/* Rótulos de interface                                                       */
/* -------------------------------------------------------------------------- */

export const OBJECTIVE_LABELS: Record<
  Objective,
  { label: string; description: string }
> = {
  compartilhamento: {
    label: "Compartilhamento",
    description: "Conteúdo relacionável e opinativo, feito para ser enviado a alguém.",
  },
  retencao_salvamento: {
    label: "Retenção e salvamento",
    description: "Conteúdo denso: tutoriais, passo a passo e dados práticos.",
  },
  comentarios: {
    label: "Comentários e engajamento",
    description: "Perguntas abertas, debate e polêmicas leves.",
  },
};

/* -------------------------------------------------------------------------- */
/* Contrato da API                                                            */
/* -------------------------------------------------------------------------- */

export interface GenerateParams {
  mode: GenerationMode;
  objective: Objective;
  /** Número total de slides, incluindo capa e CTA (2 a 10). Ignorado em "reels". */
  slides: number;
  media: MediaMode;
}

export interface Slide {
  /** Posição do slide, começando em 1. */
  n: number;
  tipo: SlideType;
  titulo: string;
  corpo: string;
  /** Sugestão de imagem ou legenda da imagem do usuário. Vazio em roteiros. */
  imagem: string;
}

export interface ReelsScript {
  /** Primeiros 3 segundos: texto na tela e fala. */
  gancho: string;
  /** Blocos de 3 a 5 segundos, em ordem. */
  corpo: string[];
  cta: string;
}

export interface ScoreCriteria {
  gancho: number;
  clareza: number;
  alinhamento_objetivo: number;
  retencao: number;
  cta: number;
}

export interface ViralScore {
  /** 0 a 100. Recalculado no servidor a partir dos critérios. */
  total: number;
  criterios: ScoreCriteria;
  pontos_fortes: string[];
  melhorias: string[];
}

export interface GenerateResult {
  resumo_pdf: string;
  /** Vazio quando o modo é "reels". */
  slides: Slide[];
  /** Nulo quando o modo não é "reels". */
  reels: ReelsScript | null;
  score: ViralScore;
}

export interface GenerateSuccessResponse {
  ok: true;
  mode: GenerationMode;
  result: GenerateResult;
}

export type ApiErrorCode =
  | "invalid_request"
  | "invalid_file"
  | "file_too_large"
  | "rate_limited"
  | "model_output_invalid"
  | "upstream_error"
  | "server_misconfigured"
  | "internal_error";

export interface GenerateErrorResponse {
  ok: false;
  error: { code: ApiErrorCode; message: string };
}

export type GenerateResponse = GenerateSuccessResponse | GenerateErrorResponse;

/** Pesos usados para calcular o score total (somam 1). */
export const VIRAL_WEIGHTS: Record<keyof ScoreCriteria, number> = {
  gancho: 0.3,
  retencao: 0.25,
  alinhamento_objetivo: 0.2,
  clareza: 0.15,
  cta: 0.1,
};

export const CRITERIA_LABELS: Record<keyof ScoreCriteria, string> = {
  gancho: "Gancho",
  clareza: "Clareza",
  alinhamento_objetivo: "Alinhamento ao objetivo",
  retencao: "Retenção",
  cta: "Chamada para ação",
};

/* -------------------------------------------------------------------------- */
/* Estado da aplicação (cliente)                                              */
/* -------------------------------------------------------------------------- */

export interface ImageItem {
  id: string;
  file: File;
  /** Object URL para pré-visualização. Deve ser revogada ao remover o item. */
  previewUrl: string;
}

export interface GeneratorFormState {
  pdf: File | null;
  refs: ImageItem[];
  ownImages: ImageItem[];
  objective: Objective;
  slides: number;
  media: MediaMode;
  scriptKind: ScriptKind;
}

export type GeneratorStatus =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "success"; mode: GenerationMode; result: GenerateResult };
